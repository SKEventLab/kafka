package com.sps.kafka.consumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.sps.kafka.processor.MessageProcessor;

@Service
public class KafkaMessageConsumer {

    private final KafkaMessageStore messageStore;

    public KafkaMessageConsumer(KafkaMessageStore messageStore) {
    	 this.messageStore = messageStore;
    }

    @KafkaListener(
            topics =  "${spring.kafka.topics}",
            groupId = "${spring.kafka.consumer.group-id}"
    )
    public void consume(String message) {

    	System.out.println("Consumed message: " + message);

        messageStore.addMessage(message);
    }
}