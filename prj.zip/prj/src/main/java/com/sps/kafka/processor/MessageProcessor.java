package com.sps.kafka.processor;

import org.springframework.stereotype.Service;

@Service
public class MessageProcessor {

    public void process(String message) {

        System.out.println(
                "Processing message: " + message
        );

        // Business logic goes here
    }
}
