package com.sps.kafka.controller;
import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.sps.kafka.consumer.KafkaMessageStore;
import com.sps.kafka.model.MessageRequest;
import com.sps.kafka.producer.KafkaMessageProducer;

@RestController
@RequestMapping("/api/messages")
public class MessageController {

    private final KafkaMessageProducer producer;
    
    private final KafkaMessageStore messageStore;

    public MessageController(KafkaMessageProducer producer,KafkaMessageStore messageStore) {
        this.producer = producer;
        this.messageStore=messageStore;
    }

    @PostMapping("/produce")
    public String sendMessage(@RequestBody MessageRequest request) {

        producer.sendMessage(request.getKey(), request.getMessage());

        return "Message sent successfully";
    }
    
    @GetMapping("/consume")
    public List<String> getMessages() {
        return messageStore.getMessages();
    }
    
    
}