package com.sps.kafka.config;

public class KafkaConfig {

	public KafkaConfig() {
		// TODO Auto-generated constructor stub
	}

}
