package com.sps.kafka.prj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjApplicationTests {

	@Test
	void contextLoads() {
	}

}
